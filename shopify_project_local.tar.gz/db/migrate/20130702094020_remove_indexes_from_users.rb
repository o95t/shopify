class RemoveIndexesFromUsers < ActiveRecord::Migration
  def change
  	remove_index :users, :account_number
    remove_index :users, :email
  end
end
