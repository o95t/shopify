class UsersController < ApplicationController

	before_filter :valid_shopify_session
	before_filter :logged_in_user, only: [:edit, :update, :update_shopify_info]

	around_filter :shopify_session, only: [:create, :update_shopify_info, :update]

	def create
				
		# Check if shop_url has not been tampered in form by matching it with the value in session
		@user = User.new(params[:user])

		@user.shop_url = session[:shopify].url

		# Set other data from Shopify

		@shop = ShopifyAPI::Shop.current


		@user.assign_attributes(
			address_line1: @shop.address1,
			city: @shop.city,
			country_code: @shop.country,
			shopify_id: @shop.id,
			company_name: @shop.name,
			cellphone: @shop.phone,
			post_code: @shop.zip,
			currency_code: @shop.currency,
			shipper_name: @shop.shop_owner,
			shopify_email: @shop.email
		)

		@user.assign_attributes(province: @shop.province) unless @shop.province.nil?
		if @user.save

			flash[:success] = "Successfully added Aramex account information"
			login(@user)
			redirect_to root_url
		else
			abort(@user.errors.messages.inspect)
			flash.now[:error] = @user.errors.messages.inspect
			flash.now[:error] = "Oops! There was some error. Please try again."
			render "new"
		end
	end

	def new
		@box = 0
		@user = User.new
		@user.shop_url = session[:shopify].url
	end

	# If the user changes some info on Shopify, and wants to update the app with the same
	def update_shopify_info
		unless current_user.nil?
			@shop = ShopifyAPI::Shop.current
			if current_user.update_attributes(
					address_line1: @shop.address1,
					city: @shop.city,
					country_code: @shop.country,
					shopify_id: @shop.id,
					company_name: @shop.name,
					cellphone: @shop.phone,
					post_code: @shop.zip,
					currency_code: @shop.currency,
					shipper_name: @shop.shop_owner,
					province: @shop.province,
					shopify_email: @shop.email
				 )
				flash[:notice] = "Shopify information updated successfully"
				redirect_to :back
			else
				flash[:error] = "Shopify information could not be updated. <br /> #{current_user.errors.full_messages}"
				redirect_to '/edit'
			end
		else
			flash[:error] = "Please login first"
			redirect_to '/login'
		end
	end

	def edit
		@user = current_user
	end

	def update
		@user = current_user
		if @user.update_attributes(params[:user])
			redirect_to root_url, notice: "Successfully updated Aramex information"
		else
			render 'edit'
		end
	end

	def default_domestic_product
		product_ar = []
		@user = current_user
    @domestic_product = @user.default_domestic_product_type
    @domestic_product.sort.each do |hash|
      Shipment.domestic_product_type_hash.sort.each do |k, v|  
        product_ar << [k, v] if hash == v    
      end
    end
   	render text: product_ar.to_json
  end

	def default_express_product
		product_ar = []
		@user = current_user
    @express_product = @user.default_international_product_type
    @express_product.sort.each do |hash|
      Shipment.express_product_type_hash.sort.each do |k, v|  
        product_ar << [k, v] if hash == v    
      end
  	end
		render text: product_ar.to_json
	end

	def default_domestic_services
		service_ar = []
		@user = current_user
    @domestic_services = @user.default_domestic_services
    @domestic_services.sort.each do |hash|
      Shipment.domestic_services_hash.sort.each do |k, v|  
        service_ar << [k, v] if hash == v    
      end
    end
   	render text: service_ar.to_json
	end

	def default_express_services
		service_ar = []
		@user = current_user
    @express_services = @user.default_international_services
    @express_services.sort.each do |hash|
      Shipment.express_services_hash.sort.each do |k, v|  
        service_ar << [k, v] if hash == v    
      end
  	end
		render text: service_ar.to_json
	end

end
