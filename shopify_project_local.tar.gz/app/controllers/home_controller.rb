class HomeController < ApplicationController
 
  # Do we need a
  before_filter :valid_shopify_session, :logged_in_user, :except => [:index] 

  # This is Shopify's filter for controlling auth
  around_filter :shopify_session
  
  # The index method for the root_url
  def index
   
    # Get latest 25 orders - latest order first 
    # @return [Array<Hash>] Latest orders from Shopify API
    # Rails.logger.info "A line before orders"
  begin
     @orders   = ShopifyAPI::Order.find(:all, :params => {:limit => 25, :order => "created_at DESC" })

  rescue StandardError => e
    flash[:error] = "#{e}"
  end

  end  
end