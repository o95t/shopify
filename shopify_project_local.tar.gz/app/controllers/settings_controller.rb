class SettingsController < ApplicationController

end
