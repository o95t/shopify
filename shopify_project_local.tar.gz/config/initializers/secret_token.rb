# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ShopifyAramex::Application.config.secret_token = '3a7821d7d34629b3b42762eb9d5d888510f0cfb2f8a9e3ebf5918fc2f7699c2064021bb1866dd9ae8cfe4117bd7147570700bd835c4c6455c4327ec6cd2f41e5'
