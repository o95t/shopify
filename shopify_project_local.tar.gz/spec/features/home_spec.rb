require 'spec_helper'

describe "Home Page" do
	
end