require 'spec_helper'

feature "Settings" do

	
end