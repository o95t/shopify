require 'spec_helper'

describe TrackingsController do

end
