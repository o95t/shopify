require 'spec_helper'

describe OrdersController do

end
