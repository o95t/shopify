require 'spec_helper'

describe PickupsController do

end
