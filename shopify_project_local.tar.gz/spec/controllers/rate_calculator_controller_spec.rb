require 'spec_helper'

describe RateCalculatorController do

end
