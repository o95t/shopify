require 'spec_helper'

describe ShipmentController do

end
