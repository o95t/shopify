# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :pickup_store do
    user nil
    aramex_id "MyString"
    guid "MyString"
    product_group "MyString"
  end
end
